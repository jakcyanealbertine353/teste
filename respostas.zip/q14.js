const funcao = (...argumentos) => {
  return argumentos[0] + argumentos[1];
}

console.log(funcao("kmfkf","lml"));