const retornarTamanhoStrings = vetor => vetor.map(elemento => elemento.length);

console.log(retornarTamanhoStrings(["lkmlk","kj","kmlkkkjkk"]));