const comprimentosDasStrings = (arrayDeStrings) => arrayDeStrings.map(string => string.length);

console.log(comprimentosDasStrings(["12","dfdf","44"]));