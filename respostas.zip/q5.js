const calcularQuadrado = (elementos) => {
  return elementos.map(elemento => elemento * elemento);
}

console.log(calcularQuadrado([2,3,4]))