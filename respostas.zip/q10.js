const ponto = {x: 22, y : 34}
const {x,y} = ponto;
console.log(x,y);